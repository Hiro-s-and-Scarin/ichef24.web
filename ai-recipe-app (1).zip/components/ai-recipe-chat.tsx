"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ChefHat, Send, Sparkles } from "lucide-react"

interface AIRecipeChatProps {
  onRecipeGenerated?: (recipe: any) => void
}

export function AIRecipeChat({ onRecipeGenerated }: AIRecipeChatProps) {
  const [input, setInput] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    if (!input.trim() || isGenerating) return

    setIsGenerating(true)

    // Simulate AI recipe generation
    setTimeout(() => {
      const generatedRecipe = {
        id: Date.now(),
        title: "Receita Gerada pela IA",
        description: `Uma receita personalizada baseada em: "${input}"`,
        image: "/placeholder.svg?height=200&width=300",
        time: "25 min",
        servings: "3 pessoas",
        difficulty: "Médio",
        tags: ["IA", "Personalizada", "Rápida"],
        date: "Agora",
        rating: 5,
        ingredients: ["Ingredientes selecionados pela IA", "Temperos especiais", "Elementos únicos da receita"],
        instructions: [
          "Prepare os ingredientes conforme sugerido",
          "Siga as técnicas culinárias recomendadas",
          "Finalize com o toque especial",
        ],
      }

      if (onRecipeGenerated) {
        onRecipeGenerated(generatedRecipe)
      }

      setInput("")
      setIsGenerating(false)
    }, 3000)
  }

  return (
    <Card className="bg-white/90 border-orange-200 backdrop-blur-sm dark:bg-gray-800/90 dark:border-gray-600">
      <CardContent className="p-6 space-y-6">
        <div className="text-center space-y-3">
          <div className="w-12 h-12 bg-gradient-to-r from-orange-600 to-yellow-500 rounded-xl flex items-center justify-center mx-auto">
            <ChefHat className="w-6 h-6 text-white" />
          </div>
          <h3 className="text-xl font-semibold text-gray-800 dark:text-white">Chat com IA</h3>
          <p className="text-gray-600 text-sm dark:text-gray-300">
            Converse com o iChef24 e gere receitas personalizadas
          </p>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="relative">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder="Ex: Quero uma receita com frango e limão..."
              className="pr-12 bg-orange-50 border-orange-200 text-gray-800 placeholder:text-gray-500 dark:bg-gray-700 dark:border-gray-600 dark:text-white dark:placeholder:text-gray-400"
              disabled={isGenerating}
            />
            <Button
              type="submit"
              size="icon"
              disabled={!input.trim() || isGenerating}
              className="absolute right-1 top-1 h-8 w-8 bg-gradient-to-r from-orange-600 to-yellow-500 hover:from-yellow-500 hover:to-orange-600"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>

          {isGenerating && (
            <div className="flex items-center justify-center gap-2 text-orange-600 py-4">
              <Sparkles className="w-5 h-5 animate-spin" />
              <span className="text-sm">Gerando receita personalizada...</span>
            </div>
          )}
        </form>

        <div className="space-y-2">
          <p className="text-xs text-gray-500 text-center dark:text-gray-400">Sugestões rápidas:</p>
          <div className="flex flex-wrap gap-2">
            {["Receita vegetariana", "Prato com frango", "Sobremesa rápida", "Comida italiana"].map((suggestion) => (
              <Button
                key={suggestion}
                variant="outline"
                size="sm"
                onClick={() => setInput(suggestion)}
                className="text-xs border-orange-200 text-gray-600 hover:text-gray-800 hover:bg-orange-100 dark:border-gray-600 dark:text-gray-300 dark:hover:text-white dark:hover:bg-gray-700"
                disabled={isGenerating}
              >
                {suggestion}
              </Button>
            ))}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
