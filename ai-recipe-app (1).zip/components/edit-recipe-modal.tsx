"use client"

import { useState, useEffect } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Badge } from "@/components/ui/badge"
import { Plus, X, Save, Wand2 } from "lucide-react"

interface EditRecipeModalProps {
  recipe: any | null
  isOpen: boolean
  onClose: () => void
  onSave: (recipe: any) => void
}

export function EditRecipeModal({ recipe, isOpen, onClose, onSave }: EditRecipeModalProps) {
  const [formData, setFormData] = useState({
    title: "",
    description: "",
    time: "",
    servings: "",
    difficulty: "Fácil",
    tags: [] as string[],
    ingredients: [""],
    instructions: [""],
  })
  const [newTag, setNewTag] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)

  useEffect(() => {
    if (recipe) {
      setFormData({
        title: recipe.title || "",
        description: recipe.description || "",
        time: recipe.time || "",
        servings: recipe.servings || "",
        difficulty: recipe.difficulty || "Fácil",
        tags: recipe.tags || [],
        ingredients: recipe.ingredients || [""],
        instructions: recipe.instructions || [""],
      })
    }
  }, [recipe])

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const addIngredient = () => {
    setFormData((prev) => ({ ...prev, ingredients: [...prev.ingredients, ""] }))
  }

  const removeIngredient = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      ingredients: prev.ingredients.filter((_, i) => i !== index),
    }))
  }

  const updateIngredient = (index: number, value: string) => {
    setFormData((prev) => ({
      ...prev,
      ingredients: prev.ingredients.map((item, i) => (i === index ? value : item)),
    }))
  }

  const addInstruction = () => {
    setFormData((prev) => ({ ...prev, instructions: [...prev.instructions, ""] }))
  }

  const removeInstruction = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      instructions: prev.instructions.filter((_, i) => i !== index),
    }))
  }

  const updateInstruction = (index: number, value: string) => {
    setFormData((prev) => ({
      ...prev,
      instructions: prev.instructions.map((item, i) => (i === index ? value : item)),
    }))
  }

  const addTag = () => {
    if (newTag.trim() && !formData.tags.includes(newTag.trim())) {
      setFormData((prev) => ({ ...prev, tags: [...prev.tags, newTag.trim()] }))
      setNewTag("")
    }
  }

  const removeTag = (tagToRemove: string) => {
    setFormData((prev) => ({
      ...prev,
      tags: prev.tags.filter((tag) => tag !== tagToRemove),
    }))
  }

  const generateWithAI = async () => {
    setIsGenerating(true)

    // Simulate AI generation
    setTimeout(() => {
      setFormData((prev) => ({
        ...prev,
        title: prev.title || "Receita Melhorada por IA",
        description: prev.description || "Uma deliciosa receita aprimorada pela nossa IA.",
        time: prev.time || "30 minutos",
        servings: prev.servings || "4 pessoas",
        tags: prev.tags.length > 0 ? [...prev.tags, "IA", "Melhorada"] : ["IA", "Melhorada"],
        ingredients: prev.ingredients[0]
          ? prev.ingredients
          : ["2 xícaras de ingrediente principal", "1 xícara de ingrediente secundário", "Temperos a gosto"],
        instructions: prev.instructions[0]
          ? prev.instructions
          : [
              "Prepare todos os ingredientes",
              "Misture os ingredientes principais",
              "Cozinhe conforme necessário",
              "Sirva quente",
            ],
      }))
      setIsGenerating(false)
    }, 2000)
  }

  const handleSave = () => {
    const updatedRecipe = {
      ...recipe,
      ...formData,
      date: "Editado hoje",
    }
    onSave(updatedRecipe)
    onClose()
  }

  if (!recipe) return null

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-[#2f2f2f] border-[#464545] text-white">
        <DialogHeader>
          <DialogTitle className="text-2xl text-white">Editar Receita</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Basic Info */}
          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white">Título da Receita</Label>
              <Input
                value={formData.title}
                onChange={(e) => handleInputChange("title", e.target.value)}
                placeholder="Nome da sua receita"
                className="bg-[#1b1b1b]/50 border-[#464545] text-white"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-white">Tempo de Preparo</Label>
              <Input
                value={formData.time}
                onChange={(e) => handleInputChange("time", e.target.value)}
                placeholder="Ex: 30 minutos"
                className="bg-[#1b1b1b]/50 border-[#464545] text-white"
              />
            </div>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label className="text-white">Porções</Label>
              <Input
                value={formData.servings}
                onChange={(e) => handleInputChange("servings", e.target.value)}
                placeholder="Ex: 4 pessoas"
                className="bg-[#1b1b1b]/50 border-[#464545] text-white"
              />
            </div>
            <div className="space-y-2">
              <Label className="text-white">Dificuldade</Label>
              <select
                value={formData.difficulty}
                onChange={(e) => handleInputChange("difficulty", e.target.value)}
                className="w-full p-2 bg-[#1b1b1b]/50 border border-[#464545] rounded-md text-white"
              >
                <option value="Fácil">Fácil</option>
                <option value="Médio">Médio</option>
                <option value="Difícil">Difícil</option>
              </select>
            </div>
          </div>

          <div className="space-y-2">
            <Label className="text-white">Descrição</Label>
            <Textarea
              value={formData.description}
              onChange={(e) => handleInputChange("description", e.target.value)}
              placeholder="Descreva sua receita..."
              className="bg-[#1b1b1b]/50 border-[#464545] text-white"
              rows={3}
            />
          </div>

          {/* Tags */}
          <div className="space-y-2">
            <Label className="text-white">Tags</Label>
            <div className="flex gap-2 mb-2">
              <Input
                value={newTag}
                onChange={(e) => setNewTag(e.target.value)}
                placeholder="Adicionar tag"
                className="bg-[#1b1b1b]/50 border-[#464545] text-white"
                onKeyPress={(e) => e.key === "Enter" && addTag()}
              />
              <Button onClick={addTag} variant="outline" className="border-[#464545] text-gray-300 bg-transparent">
                <Plus className="w-4 h-4" />
              </Button>
            </div>
            <div className="flex flex-wrap gap-2">
              {formData.tags.map((tag, index) => (
                <Badge key={index} className="bg-[#ff7518]/20 text-[#ff7518] border-[#ff7518]/30">
                  {tag}
                  <button onClick={() => removeTag(tag)} className="ml-2">
                    <X className="w-3 h-3" />
                  </button>
                </Badge>
              ))}
            </div>
          </div>

          {/* Ingredients */}
          <div className="space-y-2">
            <Label className="text-white">Ingredientes</Label>
            {formData.ingredients.map((ingredient, index) => (
              <div key={index} className="flex gap-2">
                <Input
                  value={ingredient}
                  onChange={(e) => updateIngredient(index, e.target.value)}
                  placeholder="Ex: 2 xícaras de farinha"
                  className="bg-[#1b1b1b]/50 border-[#464545] text-white"
                />
                {formData.ingredients.length > 1 && (
                  <Button
                    onClick={() => removeIngredient(index)}
                    variant="outline"
                    size="icon"
                    className="border-[#464545] text-gray-300"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                )}
              </div>
            ))}
            <Button onClick={addIngredient} variant="outline" className="border-[#464545] text-gray-300 bg-transparent">
              <Plus className="w-4 h-4 mr-2" />
              Adicionar Ingrediente
            </Button>
          </div>

          {/* Instructions */}
          <div className="space-y-2">
            <Label className="text-white">Modo de Preparo</Label>
            {formData.instructions.map((instruction, index) => (
              <div key={index} className="flex gap-2">
                <div className="w-8 h-8 bg-gradient-to-r from-[#f54703] to-[#ff7518] rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0 mt-2">
                  {index + 1}
                </div>
                <Textarea
                  value={instruction}
                  onChange={(e) => updateInstruction(index, e.target.value)}
                  placeholder="Descreva este passo..."
                  className="bg-[#1b1b1b]/50 border-[#464545] text-white"
                  rows={2}
                />
                {formData.instructions.length > 1 && (
                  <Button
                    onClick={() => removeInstruction(index)}
                    variant="outline"
                    size="icon"
                    className="border-[#464545] text-gray-300 mt-2"
                  >
                    <X className="w-4 h-4" />
                  </Button>
                )}
              </div>
            ))}
            <Button
              onClick={addInstruction}
              variant="outline"
              className="border-[#464545] text-gray-300 bg-transparent"
            >
              <Plus className="w-4 h-4 mr-2" />
              Adicionar Passo
            </Button>
          </div>

          {/* Actions */}
          <div className="flex gap-4 pt-4 border-t border-[#464545]">
            <Button
              onClick={generateWithAI}
              disabled={isGenerating}
              variant="outline"
              className="border-[#ff7518] text-[#ff7518] hover:bg-[#ff7518]/10 bg-transparent"
            >
              {isGenerating ? (
                "Melhorando..."
              ) : (
                <>
                  <Wand2 className="w-4 h-4 mr-2" />
                  Melhorar com IA
                </>
              )}
            </Button>
            <div className="flex-1" />
            <Button onClick={onClose} variant="outline" className="border-[#464545] text-gray-300 bg-transparent">
              Cancelar
            </Button>
            <Button
              onClick={handleSave}
              className="bg-gradient-to-r from-[#f54703] to-[#ff7518] hover:from-[#ff7518] hover:to-[#f54703] text-white"
            >
              <Save className="w-4 h-4 mr-2" />
              Salvar Alterações
            </Button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
