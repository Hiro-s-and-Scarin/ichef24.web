"use client"

import { useState } from "react"
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Heart, Share2, Clock, Users, Utensils, BookOpen, Star, X } from "lucide-react"
import Image from "next/image"

interface Recipe {
  id: number
  title: string
  description: string
  image: string
  time: string
  servings: string
  difficulty: string
  tags: string[]
  rating: number
  ingredients: string[]
  instructions: string[]
  nutrition?: {
    calories: number
    protein: string
    carbs: string
    fat: string
  }
}

interface RecipeModalProps {
  recipe: Recipe | null
  isOpen: boolean
  onClose: () => void
  onFavorite?: (id: number) => void
  isFavorite?: boolean
}

export function RecipeModal({ recipe, isOpen, onClose, onFavorite, isFavorite = false }: RecipeModalProps) {
  const [userRating, setUserRating] = useState(0)

  if (!recipe) return null

  const handleRating = (rating: number) => {
    setUserRating(rating)
    // In a real app, this would save to backend
  }

  const handleShare = () => {
    if (navigator.share) {
      navigator.share({
        title: recipe.title,
        text: recipe.description,
        url: window.location.href,
      })
    } else {
      // Fallback - copy to clipboard
      navigator.clipboard.writeText(window.location.href)
      alert("Link copiado para a área de transferência!")
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-[#2f2f2f] border-[#464545] text-white">
        <DialogHeader className="relative">
          <Button
            variant="ghost"
            size="icon"
            onClick={onClose}
            className="absolute right-0 top-0 text-gray-400 hover:text-white"
          >
            <X className="w-4 h-4" />
          </Button>
          <DialogTitle className="text-2xl text-white pr-8">{recipe.title}</DialogTitle>
        </DialogHeader>

        <div className="space-y-6">
          {/* Recipe Header */}
          <div className="relative h-64 rounded-lg overflow-hidden">
            <Image src={recipe.image || "/placeholder.svg"} alt={recipe.title} fill className="object-cover" />
            <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
            <div className="absolute bottom-4 left-4 right-4">
              <p className="text-white/90 text-lg mb-3">{recipe.description}</p>
              <div className="flex flex-wrap gap-2">
                {recipe.tags.map((tag, index) => (
                  <Badge key={index} className="bg-white/20 text-white border-white/30">
                    {tag}
                  </Badge>
                ))}
              </div>
            </div>
            <div className="absolute top-4 right-4 flex gap-2">
              <Button
                variant="secondary"
                size="sm"
                onClick={() => onFavorite?.(recipe.id)}
                className={`${
                  isFavorite ? "bg-[#ff7518] text-white hover:bg-[#f54703]" : "bg-black/50 text-white hover:bg-black/70"
                }`}
              >
                <Heart className={`w-4 h-4 ${isFavorite ? "fill-current" : ""}`} />
              </Button>
              <Button
                variant="secondary"
                size="sm"
                onClick={handleShare}
                className="bg-black/50 text-white hover:bg-black/70"
              >
                <Share2 className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Recipe Stats */}
          <div className="grid grid-cols-3 gap-6 p-4 bg-[#1b1b1b]/50 rounded-lg">
            <div className="text-center">
              <Clock className="w-6 h-6 text-[#ff7518] mx-auto mb-2" />
              <div className="text-white font-medium">{recipe.time}</div>
              <div className="text-gray-400 text-sm">Tempo</div>
            </div>
            <div className="text-center">
              <Users className="w-6 h-6 text-[#ff7518] mx-auto mb-2" />
              <div className="text-white font-medium">{recipe.servings}</div>
              <div className="text-gray-400 text-sm">Porções</div>
            </div>
            <div className="text-center">
              <Utensils className="w-6 h-6 text-[#ff7518] mx-auto mb-2" />
              <div className="text-white font-medium">{recipe.difficulty}</div>
              <div className="text-gray-400 text-sm">Dificuldade</div>
            </div>
          </div>

          <div className="grid lg:grid-cols-2 gap-8">
            {/* Ingredients */}
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-white flex items-center gap-2">
                <BookOpen className="w-5 h-5 text-[#ff7518]" />
                Ingredientes
              </h3>
              <ul className="space-y-3">
                {recipe.ingredients.map((ingredient, index) => (
                  <li key={index} className="flex items-start gap-3 text-gray-300">
                    <div className="w-2 h-2 bg-[#ff7518] rounded-full mt-2 flex-shrink-0"></div>
                    <span>{ingredient}</span>
                  </li>
                ))}
              </ul>
            </div>

            {/* Instructions */}
            <div className="space-y-4">
              <h3 className="text-xl font-semibold text-white flex items-center gap-2">
                <Utensils className="w-5 h-5 text-[#ff7518]" />
                Modo de Preparo
              </h3>
              <ol className="space-y-4">
                {recipe.instructions.map((instruction, index) => (
                  <li key={index} className="flex gap-3">
                    <div className="w-8 h-8 bg-gradient-to-r from-[#f54703] to-[#ff7518] rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                      {index + 1}
                    </div>
                    <span className="text-gray-300 leading-relaxed pt-1">{instruction}</span>
                  </li>
                ))}
              </ol>
            </div>
          </div>

          {/* Nutrition & Rating */}
          <div className="grid md:grid-cols-2 gap-6">
            {recipe.nutrition && (
              <div className="p-4 bg-[#1b1b1b]/50 rounded-lg">
                <h3 className="text-lg font-semibold text-white mb-4">Informações Nutricionais</h3>
                <div className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-300">Calorias</span>
                    <span className="text-white font-medium">{recipe.nutrition.calories}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Proteína</span>
                    <span className="text-white font-medium">{recipe.nutrition.protein}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Carboidratos</span>
                    <span className="text-white font-medium">{recipe.nutrition.carbs}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-300">Gordura</span>
                    <span className="text-white font-medium">{recipe.nutrition.fat}</span>
                  </div>
                </div>
              </div>
            )}

            <div className="p-4 bg-[#1b1b1b]/50 rounded-lg">
              <h3 className="text-lg font-semibold text-white mb-4">Avalie esta receita</h3>
              <div className="flex gap-2 mb-4">
                {[1, 2, 3, 4, 5].map((star) => (
                  <button key={star} onClick={() => handleRating(star)} className="transition-colors">
                    <Star
                      className={`w-6 h-6 ${
                        star <= userRating ? "fill-[#ff7518] text-[#ff7518]" : "text-gray-600 hover:text-[#ff7518]"
                      }`}
                    />
                  </button>
                ))}
              </div>
              {userRating > 0 && (
                <p className="text-sm text-gray-300">
                  Obrigado pela sua avaliação de {userRating} estrela{userRating > 1 ? "s" : ""}!
                </p>
              )}
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  )
}
