"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { ChefHat, Sparkles, Clock, Users, Star, ArrowRight, Brain, Utensils, Heart } from "lucide-react"
import Link from "next/link"
import { AIRecipeChat } from "@/components/ai-recipe-chat"
import { ThemeToggle } from "@/components/theme-toggle"

export default function LandingPage() {
  const [activeFeature, setActiveFeature] = useState(0)
  const [generatedRecipe, setGeneratedRecipe] = useState<any>(null)

  const features = [
    {
      icon: <Brain className="w-6 h-6" />,
      title: "IA Avançada",
      description:
        "Algoritmos inteligentes que criam receitas personalizadas baseadas em seus ingredientes e preferências.",
    },
    {
      icon: <Utensils className="w-6 h-6" />,
      title: "Receitas Personalizadas",
      description:
        "Milhares de combinações únicas adaptadas ao seu gosto, restrições alimentares e ingredientes disponíveis.",
    },
    {
      icon: <Heart className="w-6 h-6" />,
      title: "Nutrição Inteligente",
      description: "Receitas balanceadas com informações nutricionais detalhadas para uma alimentação saudável.",
    },
  ]

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-50 via-orange-100 to-yellow-100 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="border-b border-orange-200/50 backdrop-blur-sm bg-white/80 sticky top-0 z-50 dark:border-gray-700/50 dark:bg-gray-900/80">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-orange-600 to-yellow-500 rounded-xl flex items-center justify-center">
              <ChefHat className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-gray-800 dark:text-white">iChef24</span>
          </div>

          <nav className="hidden md:flex items-center gap-8">
            <Link
              href="/#features"
              className="text-gray-600 hover:text-orange-600 transition-colors dark:text-gray-300 dark:hover:text-orange-400"
            >
              Recursos
            </Link>
            <Link
              href="/#pricing"
              className="text-gray-600 hover:text-orange-600 transition-colors dark:text-gray-300 dark:hover:text-orange-400"
            >
              Planos
            </Link>
            <Link
              href="/generate"
              className="text-gray-600 hover:text-orange-600 transition-colors dark:text-gray-300 dark:hover:text-orange-400"
            >
              Gerar Receita
            </Link>
            <Link
              href="/home-teste"
              className="text-gray-600 hover:text-orange-600 transition-colors dark:text-gray-300 dark:hover:text-orange-400"
            >
              Home Teste
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <ThemeToggle />
            <Button
              variant="ghost"
              className="text-gray-600 hover:text-gray-800 hover:bg-orange-100 dark:text-gray-300 dark:hover:text-white dark:hover:bg-gray-700"
            >
              Entrar
            </Button>
            <Button
              className="bg-gradient-to-r from-orange-600 to-yellow-500 hover:from-yellow-500 hover:to-orange-600 text-white border-0"
              asChild
            >
              <Link href="/plans">Começar Grátis</Link>
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-20">
        <div className="grid lg:grid-cols-2 gap-12 items-center">
          <div className="space-y-8">
            <div className="space-y-4">
              <Badge className="bg-orange-200 text-orange-800 border-orange-300 hover:bg-orange-300 dark:bg-orange-900/50 dark:text-orange-300 dark:border-orange-700">
                <Sparkles className="w-4 h-4 mr-2" />
                Powered by AI
              </Badge>
              <h1 className="text-5xl lg:text-6xl font-bold text-gray-800 leading-tight dark:text-white">
                Crie receitas
                <span className="bg-gradient-to-r from-orange-600 to-yellow-500 bg-clip-text text-transparent">
                  {" "}
                  incríveis{" "}
                </span>
                com IA
              </h1>
              <p className="text-xl text-gray-600 leading-relaxed dark:text-gray-300">
                Transforme seus ingredientes em pratos extraordinários. Nossa IA cria receitas personalizadas que se
                adaptam ao seu gosto, restrições e ingredientes disponíveis.
              </p>
            </div>

            <div className="flex flex-col sm:flex-row gap-4">
              <Button
                size="lg"
                className="bg-gradient-to-r from-orange-600 to-yellow-500 hover:from-yellow-500 hover:to-orange-600 text-white border-0 text-lg px-8 py-6"
                asChild
              >
                <Link href="/plans">
                  Gerar Minha Primeira Receita
                  <ArrowRight className="w-5 h-5 ml-2" />
                </Link>
              </Button>
              <Button
                size="lg"
                variant="outline"
                className="border-orange-300 text-orange-700 hover:bg-orange-100 hover:text-orange-800 text-lg px-8 py-6 dark:border-gray-600 dark:text-gray-300 dark:hover:bg-gray-700 dark:hover:text-white bg-transparent"
              >
                Ver Demonstração
              </Button>
            </div>

            <div className="flex items-center gap-8 pt-4">
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-800 dark:text-white">50K+</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Receitas Geradas</div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-800 dark:text-white">4.9</div>
                <div className="text-sm text-gray-600 flex items-center gap-1 dark:text-gray-400">
                  <Star className="w-4 h-4 fill-orange-500 text-orange-500" />
                  Avaliação
                </div>
              </div>
              <div className="text-center">
                <div className="text-2xl font-bold text-gray-800 dark:text-white">10K+</div>
                <div className="text-sm text-gray-600 dark:text-gray-400">Usuários Ativos</div>
              </div>
            </div>
          </div>

          {/* AI Chat Component - Desktop */}
          <div className="hidden lg:block">
            <AIRecipeChat onRecipeGenerated={setGeneratedRecipe} />
          </div>
        </div>

        {/* AI Chat Component - Mobile */}
        <div className="lg:hidden mt-12">
          <AIRecipeChat onRecipeGenerated={setGeneratedRecipe} />
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-orange-50/50 dark:bg-gray-800/50">
        <div className="container mx-auto px-4">
          <div className="text-center space-y-4 mb-16">
            <h2 className="text-4xl font-bold text-gray-800 dark:text-white">Como Funciona</h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto dark:text-gray-300">
              Nossa IA revolucionária transforma a forma como você cozinha, criando receitas únicas e deliciosas.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            {features.map((feature, index) => (
              <Card
                key={index}
                className={`bg-white/80 border-orange-200 hover:border-orange-400 transition-all duration-300 cursor-pointer dark:bg-gray-800/80 dark:border-gray-600 dark:hover:border-orange-500 ${
                  activeFeature === index
                    ? "border-orange-400 bg-orange-50 dark:border-orange-500 dark:bg-orange-900/20"
                    : ""
                }`}
                onMouseEnter={() => setActiveFeature(index)}
              >
                <CardContent className="p-8 text-center space-y-4">
                  <div className="w-16 h-16 bg-gradient-to-r from-orange-600 to-yellow-500 rounded-2xl flex items-center justify-center mx-auto">
                    {feature.icon}
                  </div>
                  <h3 className="text-xl font-semibold text-gray-800 dark:text-white">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed dark:text-gray-300">{feature.description}</p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20">
        <div className="container mx-auto px-4 text-center">
          <Card className="bg-gradient-to-r from-orange-100 to-yellow-100 border-orange-300 max-w-4xl mx-auto dark:from-gray-800 dark:to-gray-700 dark:border-gray-600">
            <CardContent className="p-12 space-y-8">
              <div className="space-y-4">
                <h2 className="text-4xl font-bold text-gray-800 dark:text-white">
                  Pronto para Revolucionar sua Cozinha?
                </h2>
                <p className="text-xl text-gray-600 dark:text-gray-300">
                  Junte-se a milhares de chefs que já descobriram o poder da culinária com IA.
                </p>
              </div>

              <div className="flex flex-col sm:flex-row gap-4 justify-center">
                <Button
                  size="lg"
                  className="bg-gradient-to-r from-orange-600 to-yellow-500 hover:from-yellow-500 hover:to-orange-600 text-white border-0 text-lg px-8 py-6"
                  asChild
                >
                  <Link href="/plans">
                    Começar Agora - É Grátis
                    <Sparkles className="w-5 h-5 ml-2" />
                  </Link>
                </Button>
              </div>

              <div className="flex items-center justify-center gap-6 text-sm text-gray-600 dark:text-gray-400">
                <div className="flex items-center gap-2">
                  <Clock className="w-4 h-4" />
                  Setup em 30 segundos
                </div>
                <div className="flex items-center gap-2">
                  <Users className="w-4 h-4" />
                  Sem cartão de crédito
                </div>
                <div className="flex items-center gap-2">
                  <Star className="w-4 h-4" />
                  Suporte 24/7
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </section>
    </div>
  )
}
