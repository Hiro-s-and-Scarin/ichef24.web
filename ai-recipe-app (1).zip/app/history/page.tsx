"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import {
  ChefHat,
  Search,
  Heart,
  Share2,
  Clock,
  Users,
  Filter,
  Grid3X3,
  List,
  Star,
  Plus,
  Edit,
  Sparkles,
} from "lucide-react"
import Link from "next/link"
import Image from "next/image"
import { RecipeModal } from "@/components/recipe-modal"
import { CreateRecipeModal } from "@/components/create-recipe-modal"
import { useAuth } from "@/contexts/auth-context"
import { EditRecipeModal } from "@/components/edit-recipe-modal"
import { AIChatModal } from "@/components/ai-chat-modal"

export default function HistoryPage() {
  const [searchTerm, setSearchTerm] = useState("")
  const [viewMode, setViewMode] = useState<"grid" | "list">("grid")
  const [favoriteIds, setFavoriteIds] = useState<number[]>([1, 3, 5])
  const [selectedRecipe, setSelectedRecipe] = useState<any>(null)
  const [isRecipeModalOpen, setIsRecipeModalOpen] = useState(false)
  const [isCreateModalOpen, setIsCreateModalOpen] = useState(false)
  const [isEditModalOpen, setIsEditModalOpen] = useState(false)
  const [recipeToEdit, setRecipeToEdit] = useState<any>(null)
  const [recipes, setRecipes] = useState([
    {
      id: 1,
      title: "Risotto de Frango com Limão",
      description: "Um risotto cremoso e aromático com frango suculento e ervas frescas",
      image: "/placeholder.svg?height=200&width=300",
      time: "35 min",
      servings: "4 pessoas",
      difficulty: "Médio",
      tags: ["Italiano", "Cremoso", "Proteína"],
      date: "Hoje",
      rating: 5,
      ingredients: [
        "400g de arroz arbóreo",
        "500g de peito de frango em cubos",
        "1 litro de caldo de galinha",
        "1 cebola média picada",
        "2 dentes de alho picados",
        "1/2 xícara de vinho branco",
        "Suco de 1 limão",
        "Raspas de 1 limão",
        "50g de parmesão ralado",
        "2 colheres de sopa de manteiga",
        "Salsinha e tomilho frescos",
        "Sal e pimenta a gosto",
      ],
      instructions: [
        "Aqueça o caldo de galinha em uma panela e mantenha em fogo baixo.",
        "Em uma panela grande, refogue a cebola e o alho na manteiga até ficarem dourados.",
        "Adicione o frango e cozinhe até dourar por todos os lados.",
        "Acrescente o arroz e mexa por 2 minutos até os grãos ficarem nacarados.",
        "Adicione o vinho branco e mexa até evaporar.",
        "Adicione o caldo quente, uma concha por vez, mexendo sempre até ser absorvido.",
        "Continue o processo por cerca de 18-20 minutos até o arroz ficar cremoso.",
        "Finalize com parmesão, suco e raspas de limão, ervas frescas.",
        "Tempere com sal e pimenta. Sirva imediatamente.",
      ],
      nutrition: {
        calories: 420,
        protein: "28g",
        carbs: "45g",
        fat: "12g",
      },
    },
    {
      id: 2,
      title: "Salada Mediterrânea com Quinoa",
      description: "Salada nutritiva com quinoa, tomates, pepino e queijo feta",
      image: "/placeholder.svg?height=200&width=300",
      time: "15 min",
      servings: "2 pessoas",
      difficulty: "Fácil",
      tags: ["Saudável", "Vegetariano", "Rápido"],
      date: "Ontem",
      rating: 4,
      ingredients: [
        "1 xícara de quinoa cozida",
        "2 tomates médios em cubos",
        "1 pepino em fatias",
        "100g de queijo feta",
        "Azeitonas pretas",
        "Azeite extra virgem",
        "Limão",
        "Orégano",
      ],
      instructions: [
        "Cozinhe a quinoa conforme instruções da embalagem.",
        "Corte os tomates e pepino em cubos pequenos.",
        "Misture todos os ingredientes em uma tigela.",
        "Tempere com azeite, limão e orégano.",
        "Sirva gelado.",
      ],
    },
    {
      id: 3,
      title: "Salmão Grelhado com Aspargos",
      description: "Salmão perfeitamente grelhado com aspargos e molho de limão",
      image: "/placeholder.svg?height=200&width=300",
      time: "25 min",
      servings: "2 pessoas",
      difficulty: "Médio",
      tags: ["Peixe", "Saudável", "Proteína"],
      date: "2 dias atrás",
      rating: 5,
      ingredients: ["2 filés de salmão", "500g de aspargos", "2 limões", "Azeite", "Alho", "Sal e pimenta"],
      instructions: [
        "Tempere o salmão com sal, pimenta e limão.",
        "Grelhe o salmão por 4-5 minutos de cada lado.",
        "Refogue os aspargos com alho.",
        "Sirva com molho de limão.",
      ],
    },
    {
      id: 4,
      title: "Brownie de Chocolate Vegano",
      description: "Brownie fudgy e delicioso feito com ingredientes 100% vegetais",
      image: "/placeholder.svg?height=200&width=300",
      time: "45 min",
      servings: "8 pessoas",
      difficulty: "Fácil",
      tags: ["Vegano", "Sobremesa", "Chocolate"],
      date: "3 dias atrás",
      rating: 4,
      ingredients: [
        "200g de chocolate amargo",
        "150g de açúcar demerara",
        "100ml de óleo de coco",
        "2 ovos de linhaça",
        "100g de farinha",
      ],
      instructions: [
        "Derreta o chocolate com óleo de coco.",
        "Misture açúcar e ovos de linhaça.",
        "Adicione a farinha gradualmente.",
        "Asse por 25-30 minutos a 180°C.",
      ],
    },
    {
      id: 5,
      title: "Curry de Grão-de-Bico",
      description: "Curry aromático e picante com grão-de-bico e leite de coco",
      image: "/placeholder.svg?height=200&width=300",
      time: "30 min",
      servings: "4 pessoas",
      difficulty: "Médio",
      tags: ["Indiano", "Vegano", "Picante"],
      date: "1 semana atrás",
      rating: 5,
      ingredients: [
        "2 xícaras de grão-de-bico cozido",
        "400ml de leite de coco",
        "1 cebola grande",
        "3 dentes de alho",
        "Gengibre fresco",
        "Curry em pó",
        "Cúrcuma",
        "Tomates pelados",
      ],
      instructions: [
        "Refogue cebola, alho e gengibre.",
        "Adicione as especiarias e cozinhe por 1 minuto.",
        "Acrescente tomates e grão-de-bico.",
        "Adicione leite de coco e cozinhe por 15 minutos.",
        "Sirva com arroz basmati.",
      ],
    },
    {
      id: 6,
      title: "Tacos de Peixe com Molho de Abacate",
      description: "Tacos frescos com peixe grelhado e cremoso molho de abacate",
      image: "/placeholder.svg?height=200&width=300",
      time: "20 min",
      servings: "3 pessoas",
      difficulty: "Fácil",
      tags: ["Mexicano", "Peixe", "Rápido"],
      date: "1 semana atrás",
      rating: 4,
      ingredients: [
        "500g de filé de peixe branco",
        "6 tortillas de milho",
        "2 abacates maduros",
        "1 limão",
        "Coentro fresco",
        "Repolho roxo",
      ],
      instructions: [
        "Tempere e grelhe o peixe.",
        "Prepare o molho de abacate.",
        "Aqueça as tortillas.",
        "Monte os tacos com todos os ingredientes.",
      ],
    },
  ])

  const { user } = useAuth()

  const [isEditAIModalOpen, setIsEditAIModalOpen] = useState(false)
  const [isCreateAIModalOpen, setIsCreateAIModalOpen] = useState(false)
  const [recipeToEditWithAI, setRecipeToEditWithAI] = useState<any>(null)

  const toggleFavorite = (id: number) => {
    setFavoriteIds((prev) => (prev.includes(id) ? prev.filter((fId) => fId !== id) : [...prev, id]))
  }

  const openRecipeModal = (recipe: any) => {
    setSelectedRecipe(recipe)
    setIsRecipeModalOpen(true)
  }

  const openEditModal = (recipe: any) => {
    setRecipeToEdit(recipe)
    setIsEditModalOpen(true)
  }

  const handleCreateRecipe = (newRecipe: any) => {
    setRecipes((prev) => [newRecipe, ...prev])
  }

  const handleEditRecipe = (updatedRecipe: any) => {
    setRecipes((prev) => prev.map((recipe) => (recipe.id === updatedRecipe.id ? updatedRecipe : recipe)))
  }

  const openEditAIModal = (recipe: any) => {
    setRecipeToEditWithAI(recipe)
    setIsEditAIModalOpen(true)
  }

  const handleAIRecipeEdit = (updatedRecipe: any) => {
    setRecipes((prev) => prev.map((recipe) => (recipe.id === updatedRecipe.id ? updatedRecipe : recipe)))
  }

  const handleAIRecipeCreate = (newRecipe: any) => {
    setRecipes((prev) => [newRecipe, ...prev])
  }

  const filteredRecipes = recipes.filter(
    (recipe) =>
      recipe.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
      recipe.tags.some((tag) => tag.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1b1b1b] via-[#2f2f2f] to-[#464545]">
      {/* Header */}
      <header className="border-b border-[#464545]/20 backdrop-blur-sm bg-[#1b1b1b]/80">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-[#f54703] to-[#ff7518] rounded-xl flex items-center justify-center">
              <ChefHat className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-white">iChef24</span>
          </Link>

          <nav className="flex items-center gap-6">
            <Link href="/generate" className="text-gray-300 hover:text-[#ff7518] transition-colors">
              Gerar Receita
            </Link>
            <Link href="/favorites" className="text-gray-300 hover:text-[#ff7518] transition-colors">
              Favoritos
            </Link>
            {user ? (
              <div className="flex items-center gap-2">
                <span className="text-gray-300">Olá, {user.name}</span>
                <Button
                  variant="ghost"
                  onClick={() => {
                    /* logout logic */
                  }}
                  className="text-gray-300 hover:text-white"
                >
                  Sair
                </Button>
              </div>
            ) : (
              <Link href="/login" className="text-gray-300 hover:text-[#ff7518] transition-colors">
                Entrar
              </Link>
            )}
          </nav>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-7xl mx-auto space-y-8">
          {/* Page Header */}
          <div className="flex items-center justify-between">
            <div className="space-y-4">
              <h1 className="text-4xl font-bold text-white">Histórico de Receitas</h1>
              <p className="text-xl text-gray-300">Todas as suas receitas geradas pela IA</p>
            </div>
            <div className="flex gap-2">
              <Button
                onClick={() => setIsCreateModalOpen(true)}
                variant="outline"
                className="border-[#464545] text-gray-300 hover:text-white hover:bg-[#464545]/50 bg-transparent"
              >
                <Plus className="w-4 h-4 mr-2" />
                Nova Receita
              </Button>
              <Button
                onClick={() => setIsCreateAIModalOpen(true)}
                className="bg-gradient-to-r from-[#f54703] to-[#ff7518] hover:from-[#ff7518] hover:to-[#f54703] text-white border-0"
              >
                <Sparkles className="w-4 h-4 mr-2" />
                Crie Receita com IA
              </Button>
            </div>
          </div>

          {/* Search and Filters */}
          <Card className="bg-[#2f2f2f]/80 border-[#464545]/50 backdrop-blur-sm">
            <CardContent className="p-6">
              <div className="flex flex-col md:flex-row gap-4 items-center justify-between">
                <div className="relative flex-1 max-w-md">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-4 h-4" />
                  <Input
                    placeholder="Buscar receitas..."
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                    className="pl-10 bg-[#1b1b1b]/50 border-[#464545] text-white placeholder:text-gray-400"
                  />
                </div>

                <div className="flex items-center gap-2">
                  <Button
                    variant="outline"
                    className="border-[#464545] text-gray-300 hover:text-white hover:bg-[#464545]/50 bg-transparent"
                  >
                    <Filter className="w-4 h-4 mr-2" />
                    Filtros
                  </Button>

                  <div className="flex border border-[#464545] rounded-lg overflow-hidden">
                    <Button
                      variant={viewMode === "grid" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setViewMode("grid")}
                      className={
                        viewMode === "grid"
                          ? "bg-[#ff7518] text-white hover:bg-[#f54703]"
                          : "text-gray-300 hover:text-white hover:bg-[#464545]/50"
                      }
                    >
                      <Grid3X3 className="w-4 h-4" />
                    </Button>
                    <Button
                      variant={viewMode === "list" ? "default" : "ghost"}
                      size="sm"
                      onClick={() => setViewMode("list")}
                      className={
                        viewMode === "list"
                          ? "bg-[#ff7518] text-white hover:bg-[#f54703]"
                          : "text-gray-300 hover:text-white hover:bg-[#464545]/50"
                      }
                    >
                      <List className="w-4 h-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Recipes Grid/List */}
          <div className={viewMode === "grid" ? "grid md:grid-cols-2 lg:grid-cols-3 gap-6" : "space-y-4"}>
            {filteredRecipes.map((recipe) => (
              <Card
                key={recipe.id}
                className="bg-[#2f2f2f]/80 border-[#464545]/50 backdrop-blur-sm hover:border-[#ff7518]/50 transition-all duration-300 group overflow-hidden"
              >
                {viewMode === "grid" ? (
                  <CardContent className="p-0">
                    <div className="relative h-48 overflow-hidden">
                      <Image
                        src={recipe.image || "/placeholder.svg"}
                        alt={recipe.title}
                        fill
                        className="object-cover group-hover:scale-105 transition-transform duration-300"
                      />
                      <div className="absolute top-3 right-3 flex gap-2">
                        <Button
                          size="sm"
                          variant="secondary"
                          onClick={() => toggleFavorite(recipe.id)}
                          className={`w-8 h-8 p-0 ${
                            favoriteIds.includes(recipe.id)
                              ? "bg-[#ff7518] text-white hover:bg-[#f54703]"
                              : "bg-black/50 text-white hover:bg-black/70"
                          }`}
                        >
                          <Heart className={`w-4 h-4 ${favoriteIds.includes(recipe.id) ? "fill-current" : ""}`} />
                        </Button>
                      </div>
                      <div className="absolute bottom-3 left-3">
                        <Badge className="bg-black/50 text-white border-0">{recipe.date}</Badge>
                      </div>
                    </div>

                    <div className="p-6 space-y-4">
                      <div className="space-y-2">
                        <h3 className="text-xl font-semibold text-white group-hover:text-[#ff7518] transition-colors">
                          {recipe.title}
                        </h3>
                        <p className="text-gray-300 text-sm line-clamp-2">{recipe.description}</p>
                      </div>

                      <div className="flex flex-wrap gap-2">
                        {recipe.tags.map((tag, index) => (
                          <Badge
                            key={index}
                            className="bg-[#ff7518]/20 text-[#ff7518] border-[#ff7518]/30 hover:bg-[#ff7518]/30"
                          >
                            {tag}
                          </Badge>
                        ))}
                      </div>

                      <div className="flex items-center justify-between text-sm text-gray-400">
                        <div className="flex items-center gap-4">
                          <div className="flex items-center gap-1">
                            <Clock className="w-4 h-4" />
                            {recipe.time}
                          </div>
                          <div className="flex items-center gap-1">
                            <Users className="w-4 h-4" />
                            {recipe.servings}
                          </div>
                        </div>
                        <div className="flex items-center gap-1">
                          {[...Array(5)].map((_, i) => (
                            <Star
                              key={i}
                              className={`w-4 h-4 ${
                                i < recipe.rating ? "fill-[#ff7518] text-[#ff7518]" : "text-gray-600"
                              }`}
                            />
                          ))}
                        </div>
                      </div>

                      <div className="flex gap-2 pt-2">
                        <Button
                          onClick={() => openRecipeModal(recipe)}
                          className="flex-1 bg-gradient-to-r from-[#f54703] to-[#ff7518] hover:from-[#ff7518] hover:to-[#f54703] text-white border-0"
                          size="sm"
                        >
                          Ver Receita
                        </Button>
                        <Button
                          variant="outline"
                          size="sm"
                          className="border-[#464545] text-gray-300 hover:text-white hover:bg-[#464545]/50 bg-transparent"
                        >
                          <Share2 className="w-4 h-4" />
                        </Button>
                        <Button
                          onClick={() => openEditModal(recipe)}
                          variant="outline"
                          size="sm"
                          className="border-[#464545] text-gray-300 hover:text-white hover:bg-[#464545]/50 bg-transparent"
                        >
                          <Edit className="w-4 h-4" />
                        </Button>
                        <Button
                          onClick={() => openEditAIModal(recipe)}
                          variant="outline"
                          size="sm"
                          className="border-[#ff7518] text-[#ff7518] hover:text-white hover:bg-[#ff7518]/10 bg-transparent"
                        >
                          <Sparkles className="w-4 h-4" />
                        </Button>
                      </div>
                    </div>
                  </CardContent>
                ) : (
                  <CardContent className="p-6">
                    <div className="flex gap-6">
                      <div className="relative w-32 h-24 flex-shrink-0 rounded-lg overflow-hidden">
                        <Image
                          src={recipe.image || "/placeholder.svg"}
                          alt={recipe.title}
                          fill
                          className="object-cover"
                        />
                      </div>

                      <div className="flex-1 space-y-3">
                        <div className="flex items-start justify-between">
                          <div>
                            <h3 className="text-lg font-semibold text-white group-hover:text-[#ff7518] transition-colors">
                              {recipe.title}
                            </h3>
                            <p className="text-gray-300 text-sm">{recipe.description}</p>
                          </div>
                          <Button
                            size="sm"
                            variant="secondary"
                            onClick={() => toggleFavorite(recipe.id)}
                            className={`w-8 h-8 p-0 ${
                              favoriteIds.includes(recipe.id)
                                ? "bg-[#ff7518] text-white hover:bg-[#f54703]"
                                : "bg-[#464545]/50 text-gray-300 hover:bg-[#464545]"
                            }`}
                          >
                            <Heart className={`w-4 h-4 ${favoriteIds.includes(recipe.id) ? "fill-current" : ""}`} />
                          </Button>
                        </div>

                        <div className="flex items-center justify-between">
                          <div className="flex flex-wrap gap-2">
                            {recipe.tags.slice(0, 3).map((tag, index) => (
                              <Badge key={index} className="bg-[#ff7518]/20 text-[#ff7518] border-[#ff7518]/30">
                                {tag}
                              </Badge>
                            ))}
                          </div>

                          <div className="flex items-center gap-4 text-sm text-gray-400">
                            <div className="flex items-center gap-1">
                              <Clock className="w-4 h-4" />
                              {recipe.time}
                            </div>
                            <div className="flex items-center gap-1">
                              <Users className="w-4 h-4" />
                              {recipe.servings}
                            </div>
                            <Badge className="bg-black/20 text-gray-300 border-0">{recipe.date}</Badge>
                            <Button
                              onClick={() => openRecipeModal(recipe)}
                              size="sm"
                              className="bg-gradient-to-r from-[#f54703] to-[#ff7518] hover:from-[#ff7518] hover:to-[#f54703] text-white border-0"
                            >
                              Ver Receita
                            </Button>
                            <Button
                              onClick={() => openEditModal(recipe)}
                              size="sm"
                              variant="outline"
                              className="border-[#464545] text-gray-300 hover:text-white hover:bg-[#464545]/50 bg-transparent"
                            >
                              <Edit className="w-4 h-4" />
                            </Button>
                            <Button
                              onClick={() => openEditAIModal(recipe)}
                              size="sm"
                              variant="outline"
                              className="border-[#ff7518] text-[#ff7518] hover:text-white hover:bg-[#ff7518]/10 bg-transparent"
                            >
                              <Sparkles className="w-4 h-4" />
                            </Button>
                          </div>
                        </div>
                      </div>
                    </div>
                  </CardContent>
                )}
              </Card>
            ))}
          </div>

          {filteredRecipes.length === 0 && (
            <Card className="bg-[#2f2f2f]/80 border-[#464545]/50 backdrop-blur-sm">
              <CardContent className="p-12 text-center space-y-4">
                <div className="w-16 h-16 bg-[#464545]/50 rounded-full flex items-center justify-center mx-auto">
                  <Search className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-xl font-semibold text-white">Nenhuma receita encontrada</h3>
                <p className="text-gray-300">
                  Tente ajustar sua busca ou{" "}
                  <Link href="/generate" className="text-[#ff7518] hover:underline">
                    gere uma nova receita
                  </Link>
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      {/* Recipe Modal */}
      <RecipeModal
        recipe={selectedRecipe}
        isOpen={isRecipeModalOpen}
        onClose={() => setIsRecipeModalOpen(false)}
        onFavorite={toggleFavorite}
        isFavorite={selectedRecipe ? favoriteIds.includes(selectedRecipe.id) : false}
      />

      {/* Create Recipe Modal */}
      <CreateRecipeModal
        isOpen={isCreateModalOpen}
        onClose={() => setIsCreateModalOpen(false)}
        onSave={handleCreateRecipe}
      />

      {/* Edit Recipe Modal */}
      <EditRecipeModal
        recipe={recipeToEdit}
        isOpen={isEditModalOpen}
        onClose={() => setIsEditModalOpen(false)}
        onSave={handleEditRecipe}
      />

      {/* Edit Recipe with AI Modal */}
      <AIChatModal
        isOpen={isEditAIModalOpen}
        onClose={() => setIsEditAIModalOpen(false)}
        title="Editar Receita com IA"
        placeholder="Como você gostaria de melhorar esta receita?"
        initialMessage={`Olá! Vou ajudar você a melhorar a receita "${recipeToEditWithAI?.title}". Como você gostaria de modificá-la?`}
        onRecipeGenerated={handleAIRecipeEdit}
      />

      {/* Create Recipe with AI Modal */}
      <AIChatModal
        isOpen={isCreateAIModalOpen}
        onClose={() => setIsCreateAIModalOpen(false)}
        title="Criar Receita com IA"
        placeholder="Descreva a receita que você quer criar..."
        initialMessage="Olá! Sou o iChef24, sua IA culinária. Conte-me que tipo de receita você gostaria de criar e eu vou ajudar você!"
        onRecipeGenerated={handleAIRecipeCreate}
      />
    </div>
  )
}
