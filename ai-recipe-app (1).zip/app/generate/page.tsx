"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { ChefHat, Sparkles, Clock, Users, Utensils, Plus, X, Wand2, Heart, Share2, BookOpen } from "lucide-react"
import Link from "next/link"
import Image from "next/image"

export default function GeneratePage() {
  const [ingredients, setIngredients] = useState<string[]>([""])
  const [preferences, setPreferences] = useState("")
  const [isGenerating, setIsGenerating] = useState(false)
  const [generatedRecipe, setGeneratedRecipe] = useState<any>(null)
  const [isFavorite, setIsFavorite] = useState(false)

  const addIngredient = () => {
    setIngredients([...ingredients, ""])
  }

  const removeIngredient = (index: number) => {
    setIngredients(ingredients.filter((_, i) => i !== index))
  }

  const updateIngredient = (index: number, value: string) => {
    const newIngredients = [...ingredients]
    newIngredients[index] = value
    setIngredients(newIngredients)
  }

  const generateRecipe = async () => {
    setIsGenerating(true)
    // Simulate API call
    setTimeout(() => {
      setGeneratedRecipe({
        title: "Risotto de Frango com Limão e Ervas",
        description:
          "Um risotto cremoso e aromático com frango suculento, finalizado com limão fresco e ervas do jardim.",
        image: "/placeholder.svg?height=300&width=400",
        time: "35 minutos",
        difficulty: "Médio",
        servings: "4 pessoas",
        tags: ["Italiano", "Cremoso", "Proteína", "Cítrico"],
        ingredients: [
          "400g de arroz arbóreo",
          "500g de peito de frango em cubos",
          "1 litro de caldo de galinha",
          "1 cebola média picada",
          "2 dentes de alho picados",
          "1/2 xícara de vinho branco",
          "Suco de 1 limão",
          "Raspas de 1 limão",
          "50g de parmesão ralado",
          "2 colheres de sopa de manteiga",
          "Salsinha e tomilho frescos",
          "Sal e pimenta a gosto",
        ],
        instructions: [
          "Aqueça o caldo de galinha em uma panela e mantenha em fogo baixo.",
          "Em uma panela grande, refogue a cebola e o alho na manteiga até ficarem dourados.",
          "Adicione o frango e cozinhe até dourar por todos os lados.",
          "Acrescente o arroz e mexa por 2 minutos até os grãos ficarem nacarados.",
          "Adicione o vinho branco e mexa até evaporar.",
          "Adicione o caldo quente, uma concha por vez, mexendo sempre até ser absorvido.",
          "Continue o processo por cerca de 18-20 minutos até o arroz ficar cremoso.",
          "Finalize com parmesão, suco e raspas de limão, ervas frescas.",
          "Tempere com sal e pimenta. Sirva imediatamente.",
        ],
      })
      setIsGenerating(false)
    }, 3000)
  }

  const saveToHistory = () => {
    // Simulate saving to history
    alert("Receita salva no histórico!")
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-[#1b1b1b] via-[#2f2f2f] to-[#464545]">
      {/* Header */}
      <header className="border-b border-[#464545]/20 backdrop-blur-sm bg-[#1b1b1b]/80">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-[#f54703] to-[#ff7518] rounded-xl flex items-center justify-center">
              <ChefHat className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-white">iChef24</span>
          </Link>

          <nav className="flex items-center gap-6">
            <Link href="/history" className="text-gray-300 hover:text-[#ff7518] transition-colors">
              Histórico
            </Link>
            <Link href="/favorites" className="text-gray-300 hover:text-[#ff7518] transition-colors">
              Favoritos
            </Link>
          </nav>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="max-w-6xl mx-auto">
          {!generatedRecipe ? (
            <div className="grid lg:grid-cols-2 gap-8">
              {/* Input Form */}
              <Card className="bg-[#2f2f2f]/80 border-[#464545]/50 backdrop-blur-sm">
                <CardHeader>
                  <CardTitle className="text-2xl text-white flex items-center gap-3">
                    <Wand2 className="w-6 h-6 text-[#ff7518]" />
                    Gerar Nova Receita
                  </CardTitle>
                  <p className="text-gray-300">
                    Informe seus ingredientes e preferências para criar uma receita personalizada
                  </p>
                </CardHeader>
                <CardContent className="space-y-6">
                  <div className="space-y-4">
                    <label className="text-white font-medium">Ingredientes Disponíveis</label>
                    {ingredients.map((ingredient, index) => (
                      <div key={index} className="flex gap-2">
                        <Input
                          placeholder="Ex: Frango, arroz, limão..."
                          value={ingredient}
                          onChange={(e) => updateIngredient(index, e.target.value)}
                          className="bg-[#1b1b1b]/50 border-[#464545] text-white placeholder:text-gray-400"
                        />
                        {ingredients.length > 1 && (
                          <Button
                            variant="outline"
                            size="icon"
                            onClick={() => removeIngredient(index)}
                            className="border-[#464545] text-gray-400 hover:text-white hover:bg-[#464545]/50"
                          >
                            <X className="w-4 h-4" />
                          </Button>
                        )}
                      </div>
                    ))}
                    <Button
                      variant="outline"
                      onClick={addIngredient}
                      className="w-full border-[#464545] text-gray-300 hover:text-white hover:bg-[#464545]/50 bg-transparent"
                    >
                      <Plus className="w-4 h-4 mr-2" />
                      Adicionar Ingrediente
                    </Button>
                  </div>

                  <div className="space-y-2">
                    <label className="text-white font-medium">Preferências e Restrições</label>
                    <Textarea
                      placeholder="Ex: Vegetariano, sem glúten, comida italiana, pratos rápidos..."
                      value={preferences}
                      onChange={(e) => setPreferences(e.target.value)}
                      className="bg-[#1b1b1b]/50 border-[#464545] text-white placeholder:text-gray-400 min-h-[100px]"
                    />
                  </div>

                  <Button
                    onClick={generateRecipe}
                    disabled={isGenerating || ingredients.every((i) => !i.trim())}
                    className="w-full bg-gradient-to-r from-[#f54703] to-[#ff7518] hover:from-[#ff7518] hover:to-[#f54703] text-white border-0 py-6 text-lg"
                  >
                    {isGenerating ? (
                      <>
                        <Sparkles className="w-5 h-5 mr-2 animate-spin" />
                        Gerando Receita...
                      </>
                    ) : (
                      <>
                        <Wand2 className="w-5 h-5 mr-2" />
                        Gerar Receita com IA
                      </>
                    )}
                  </Button>
                </CardContent>
              </Card>

              {/* Preview/Tips */}
              <Card className="bg-[#2f2f2f]/80 border-[#464545]/50 backdrop-blur-sm">
                <CardContent className="p-8 space-y-6">
                  <div className="text-center space-y-4">
                    <div className="w-20 h-20 bg-gradient-to-r from-[#f54703] to-[#ff7518] rounded-full flex items-center justify-center mx-auto">
                      <Sparkles className="w-10 h-10 text-white" />
                    </div>
                    <h3 className="text-2xl font-bold text-white">IA Culinária Avançada</h3>
                    <p className="text-gray-300">
                      Nossa inteligência artificial analisa seus ingredientes e cria receitas únicas e deliciosas.
                    </p>
                  </div>

                  <div className="space-y-4">
                    <h4 className="text-lg font-semibold text-white">Dicas para melhores resultados:</h4>
                    <ul className="space-y-3 text-gray-300">
                      <li className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-[#ff7518] rounded-full mt-2 flex-shrink-0"></div>
                        <span>Liste todos os ingredientes que você tem disponível</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-[#ff7518] rounded-full mt-2 flex-shrink-0"></div>
                        <span>Mencione suas preferências culinárias e restrições</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-[#ff7518] rounded-full mt-2 flex-shrink-0"></div>
                        <span>Especifique o tipo de prato que deseja (entrada, prato principal, sobremesa)</span>
                      </li>
                      <li className="flex items-start gap-3">
                        <div className="w-2 h-2 bg-[#ff7518] rounded-full mt-2 flex-shrink-0"></div>
                        <span>Indique o tempo disponível para cozinhar</span>
                      </li>
                    </ul>
                  </div>
                </CardContent>
              </Card>
            </div>
          ) : (
            /* Generated Recipe */
            <div className="space-y-6">
              <div className="flex items-center justify-between">
                <Button
                  variant="outline"
                  onClick={() => setGeneratedRecipe(null)}
                  className="border-[#464545] text-gray-300 hover:text-white hover:bg-[#464545]/50"
                >
                  ← Gerar Nova Receita
                </Button>
                <div className="flex gap-2">
                  <Button
                    variant="outline"
                    onClick={() => setIsFavorite(!isFavorite)}
                    className={`border-[#464545] hover:text-white hover:bg-[#464545]/50 bg-transparent ${
                      isFavorite ? "text-[#ff7518] border-[#ff7518]/50" : "text-gray-300"
                    }`}
                  >
                    <Heart className={`w-4 h-4 mr-2 ${isFavorite ? "fill-current" : ""}`} />
                    {isFavorite ? "Favoritado" : "Favoritar"}
                  </Button>
                  <Button
                    variant="outline"
                    className="border-[#464545] text-gray-300 hover:text-white hover:bg-[#464545]/50 bg-transparent"
                  >
                    <Share2 className="w-4 h-4 mr-2" />
                    Compartilhar
                  </Button>
                  <Button
                    variant="outline"
                    onClick={saveToHistory}
                    className="border-[#464545] text-gray-300 hover:text-white hover:bg-[#464545]/50 bg-transparent"
                  >
                    <BookOpen className="w-4 h-4 mr-2" />
                    Salvar
                  </Button>
                </div>
              </div>

              <Card className="bg-[#2f2f2f]/80 border-[#464545]/50 backdrop-blur-sm overflow-hidden">
                {/* Recipe Header */}
                <div className="relative h-64 bg-gradient-to-r from-[#f54703] to-[#ff7518]">
                  <Image
                    src={generatedRecipe.image || "/placeholder.svg"}
                    alt={generatedRecipe.title}
                    fill
                    className="object-cover mix-blend-overlay"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent" />
                  <div className="absolute bottom-6 left-6 right-6">
                    <h1 className="text-3xl font-bold text-white mb-2">{generatedRecipe.title}</h1>
                    <p className="text-white/90 text-lg">{generatedRecipe.description}</p>
                    <div className="flex flex-wrap gap-2 mt-4">
                      {generatedRecipe.tags.map((tag: string, index: number) => (
                        <Badge key={index} className="bg-white/20 text-white border-white/30">
                          {tag}
                        </Badge>
                      ))}
                    </div>
                  </div>
                </div>

                {/* Recipe Info */}
                <div className="p-6 border-b border-[#464545]/50">
                  <div className="grid grid-cols-3 gap-6">
                    <div className="text-center">
                      <Clock className="w-6 h-6 text-[#ff7518] mx-auto mb-2" />
                      <div className="text-white font-medium">{generatedRecipe.time}</div>
                      <div className="text-gray-400 text-sm">Tempo</div>
                    </div>
                    <div className="text-center">
                      <Users className="w-6 h-6 text-[#ff7518] mx-auto mb-2" />
                      <div className="text-white font-medium">{generatedRecipe.servings}</div>
                      <div className="text-gray-400 text-sm">Porções</div>
                    </div>
                    <div className="text-center">
                      <Utensils className="w-6 h-6 text-[#ff7518] mx-auto mb-2" />
                      <div className="text-white font-medium">{generatedRecipe.difficulty}</div>
                      <div className="text-gray-400 text-sm">Dificuldade</div>
                    </div>
                  </div>
                </div>

                {/* Recipe Content */}
                <div className="grid lg:grid-cols-2 gap-8 p-6">
                  {/* Ingredients */}
                  <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-white flex items-center gap-2">
                      <BookOpen className="w-5 h-5 text-[#ff7518]" />
                      Ingredientes
                    </h3>
                    <ul className="space-y-3">
                      {generatedRecipe.ingredients.map((ingredient: string, index: number) => (
                        <li key={index} className="flex items-start gap-3 text-gray-300">
                          <div className="w-2 h-2 bg-[#ff7518] rounded-full mt-2 flex-shrink-0"></div>
                          <span>{ingredient}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  {/* Instructions */}
                  <div className="space-y-4">
                    <h3 className="text-xl font-semibold text-white flex items-center gap-2">
                      <Utensils className="w-5 h-5 text-[#ff7518]" />
                      Modo de Preparo
                    </h3>
                    <ol className="space-y-4">
                      {generatedRecipe.instructions.map((instruction: string, index: number) => (
                        <li key={index} className="flex gap-4">
                          <div className="w-8 h-8 bg-gradient-to-r from-[#f54703] to-[#ff7518] rounded-full flex items-center justify-center text-white font-bold text-sm flex-shrink-0">
                            {index + 1}
                          </div>
                          <span className="text-gray-300 leading-relaxed">{instruction}</span>
                        </li>
                      ))}
                    </ol>
                  </div>
                </div>
              </Card>
            </div>
          )}
        </div>
      </div>
    </div>
  )
}
