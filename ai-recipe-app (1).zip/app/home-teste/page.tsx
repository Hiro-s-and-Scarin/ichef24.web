"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { ChefHat, Send, Sparkles, User, Crown } from "lucide-react"
import Link from "next/link"
import { ThemeToggle } from "@/components/theme-toggle"

export default function HomeTestePage() {
  const [prompt, setPrompt] = useState("")
  const [mode, setMode] = useState<"amateur" | "professional">("amateur")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    if (prompt.trim()) {
      // Redirect to generate page with the prompt
      window.location.href = `/generate?prompt=${encodeURIComponent(prompt)}`
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-orange-400 via-yellow-500 to-orange-600 dark:from-gray-900 dark:via-gray-800 dark:to-gray-900">
      {/* Header */}
      <header className="border-b border-orange-300/30 backdrop-blur-sm bg-orange-500/20 dark:border-gray-700/50 dark:bg-gray-900/80">
        <div className="container mx-auto px-4 py-4 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-3">
            <div className="w-10 h-10 bg-gradient-to-r from-orange-600 to-yellow-500 rounded-xl flex items-center justify-center">
              <ChefHat className="w-6 h-6 text-white" />
            </div>
            <span className="text-2xl font-bold text-white">iChef24</span>
          </Link>

          <nav className="hidden md:flex items-center gap-8">
            <Link href="/" className="text-white/90 hover:text-white transition-colors">
              Início
            </Link>
            <Link href="/generate" className="text-white/90 hover:text-white transition-colors">
              Gerar Receita
            </Link>
            <Link href="/history" className="text-white/90 hover:text-white transition-colors">
              Histórico
            </Link>
            <Link href="/favorites" className="text-white/90 hover:text-white transition-colors">
              Favoritos
            </Link>
          </nav>

          <div className="flex items-center gap-4">
            <ThemeToggle />
            <Button variant="ghost" className="text-white/90 hover:text-white hover:bg-white/20">
              Entrar
            </Button>
            <Button className="bg-white/30 hover:bg-white/40 text-white border-white/40">Começar</Button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="container mx-auto px-4 py-20">
        <div className="max-w-4xl mx-auto text-center space-y-12">
          {/* Hero Text */}
          <div className="space-y-6">
            <h1 className="text-6xl md:text-7xl font-bold text-white">
              Crie algo{" "}
              <span className="inline-flex items-center gap-2">
                <ChefHat className="w-16 h-16 text-orange-600" />
                iChef24
              </span>
            </h1>
            <p className="text-xl md:text-2xl text-white/90 max-w-2xl mx-auto">
              Desenvolva receitas incríveis e esteja conversando com IA
            </p>
          </div>

          {/* Input Form */}
          <div className="max-w-2xl mx-auto">
            <form onSubmit={handleSubmit} className="space-y-6">
              <div className="relative">
                <Input
                  value={prompt}
                  onChange={(e) => setPrompt(e.target.value)}
                  placeholder="Peça ao iChef24 para criar uma receita..."
                  className="w-full h-16 px-6 pr-20 text-lg bg-white/95 backdrop-blur-sm border-0 rounded-2xl text-gray-800 placeholder:text-gray-600 focus:bg-white focus:ring-2 focus:ring-orange-500"
                />
                <Button
                  type="submit"
                  size="icon"
                  className="absolute right-2 top-2 h-12 w-12 bg-gradient-to-r from-orange-600 to-yellow-500 hover:from-yellow-500 hover:to-orange-600 rounded-xl"
                >
                  <Send className="w-5 h-5" />
                </Button>
              </div>

              {/* Mode Toggle */}
              <div className="flex items-center justify-center gap-4">
                <Button
                  type="button"
                  variant={mode === "amateur" ? "default" : "ghost"}
                  onClick={() => setMode("amateur")}
                  className={`flex items-center gap-2 px-6 py-3 rounded-full transition-all ${
                    mode === "amateur"
                      ? "bg-white/30 text-white border-white/40"
                      : "text-white/80 hover:text-white hover:bg-white/20"
                  }`}
                >
                  <User className="w-4 h-4" />
                  Amador
                </Button>
                <Button
                  type="button"
                  variant={mode === "professional" ? "default" : "ghost"}
                  onClick={() => setMode("professional")}
                  className={`flex items-center gap-2 px-6 py-3 rounded-full transition-all ${
                    mode === "professional"
                      ? "bg-white/30 text-white border-white/40"
                      : "text-white/80 hover:text-white hover:bg-white/20"
                  }`}
                >
                  <Crown className="w-4 h-4" />
                  Profissional
                </Button>
              </div>
            </form>
          </div>

          {/* Features */}
          <div className="grid md:grid-cols-3 gap-8 mt-20">
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-white/30 rounded-2xl flex items-center justify-center mx-auto">
                <Sparkles className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white">IA Avançada</h3>
              <p className="text-white/80">Algoritmos inteligentes que criam receitas personalizadas para você</p>
            </div>
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-white/30 rounded-2xl flex items-center justify-center mx-auto">
                <ChefHat className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white">Receitas Únicas</h3>
              <p className="text-white/80">Milhares de combinações baseadas em seus ingredientes disponíveis</p>
            </div>
            <div className="text-center space-y-4">
              <div className="w-16 h-16 bg-white/30 rounded-2xl flex items-center justify-center mx-auto">
                <User className="w-8 h-8 text-white" />
              </div>
              <h3 className="text-xl font-semibold text-white">Fácil de Usar</h3>
              <p className="text-white/80">Interface intuitiva que qualquer pessoa pode usar</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  )
}
